# Vamp

Minecraft Java 1.21.11 Fabric client-side single-player project.

## Setup
- Minecraft: 1.21.11
- Fabric Loader: 0.18.6
- Fabric API: 0.141.6+1.21.11
- Java: 21

## Chunk ESP
The chunk visualizer is enabled by default.

Press **V** to toggle it.

It draws the borders of nearby chunks that are already loaded by the client. The player's current chunk is highlighted differently.

## Build
Open the folder in IntelliJ IDEA with the Gradle plugin enabled and run the client configuration.

Or use:
- Windows: `gradlew.bat build`
- Linux/macOS: `./gradlew build`

The JAR is produced in `build/libs/`.

This project is designed for local/single-player use and does not contain anti-cheat bypasses, packet manipulation, or server-evasion code.
