package com.vamp.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.debug.DebugRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.ChunkPos;
import org.lwjgl.glfw.GLFW;

public class VampClient implements ClientModInitializer {
    public static final String MOD_ID = "vamp";

    private static boolean chunkEsp = true;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vamp.toggle_chunk_esp",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.vamp"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                chunkEsp = !chunkEsp;
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(VampClient::renderChunks);
    }

    private static void renderChunks(WorldRenderContext context) {
        if (!chunkEsp) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;
        if (context.matrices() == null || context.consumers() == null) return;

        ChunkPos center = client.player.getChunkPos();
        var camera = context.camera().getPos();

        final int radius = 4;

        for (int cx = center.x - radius; cx <= center.x + radius; cx++) {
            for (int cz = center.z - radius; cz <= center.z + radius; cz++) {
                if (!client.world.isChunkLoaded(cx, cz)) continue;

                double minX = (double) (cx << 4) - camera.x;
                double minZ = (double) (cz << 4) - camera.z;
                double maxX = minX + 16.0;
                double maxZ = minZ + 16.0;

                double minY = client.world.getBottomY() - camera.y;
                double maxY = client.world.getTopY() + 1.0 - camera.y;

                float r = cx == center.x && cz == center.z ? 0.95f : 0.25f;
                float g = cx == center.x && cz == center.z ? 0.15f : 0.75f;
                float b = 0.95f;
                float a = 0.85f;

                DebugRenderer.drawBox(
                        context.matrices(),
                        context.consumers(),
                        minX, minY, minZ,
                        maxX, maxY, maxZ,
                        r, g, b, a
                );
            }
        }
    }
}
